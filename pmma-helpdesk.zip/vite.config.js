import { defineConfig } from 'vite';
import laravel from 'laravel-vite-plugin';
import tailwindcss from '@tailwindcss/vite';
import vue from '@vitejs/plugin-vue';
import { VitePWA } from 'vite-plugin-pwa';

export default defineConfig({
    plugins: [
        laravel({
            input: ['resources/css/app.css', 'resources/js/app.js'],
            refresh: true,
        }),
        tailwindcss(),
        vue(),
        VitePWA({
            registerType: 'autoUpdate',
            manifest: {
                name: 'PMMA Support Portal',
                short_name: 'PMMA Support',
                description: 'PMMA IT support ticket portal',
                theme_color: '#10264b',
                background_color: '#f5f7fb',
                display: 'standalone',
                start_url: '/dashboard',
                icons: [
                    { src: '/assets/images/pmma-seal.png', sizes: '192x192', type: 'image/png' },
                    { src: '/assets/images/pmma-seal.png', sizes: '512x512', type: 'image/png' },
                ],
            },
        }),
    ],
    server: {
        watch: {
            ignored: ['**/storage/framework/views/**'],
        },
    },
});
