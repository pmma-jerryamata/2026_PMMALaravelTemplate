<?php

namespace App\Providers;

use Illuminate\Support\ServiceProvider;
use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;

class AppServiceProvider extends ServiceProvider
{
    /**
     * Register any application services.
     */
    public function register(): void
    {
        //
    }

    /**
     * Bootstrap any application services.
     */
    public function boot(): void
    {
        RateLimiter::for('staff-login', fn (Request $request) => [
            Limit::perMinute(20)->by('ip:'.$request->ip()),
            Limit::perMinute(5)->by('account:'.hash('sha256', strtolower((string) $request->input('email')))),
        ]);
        RateLimiter::for('public-ticket-submit', fn (Request $request) => Limit::perMinute(10)->by('ip:'.$request->ip()));
        RateLimiter::for('public-read', fn (Request $request) => Limit::perMinute(60)->by('ip:'.$request->ip()));
        RateLimiter::for('clock', fn (Request $request) => Limit::perMinute(60)->by('ip:'.$request->ip()));

        \Illuminate\Support\Facades\View::composer(['layouts.portal', 'layouts.auth', 'layouts.dashboard', 'auth.login', 'dashboard.settings', 'queue'], function ($view) {
            $view->with('systemSettings', \App\Models\SystemSetting::values());
        });
    }
}
