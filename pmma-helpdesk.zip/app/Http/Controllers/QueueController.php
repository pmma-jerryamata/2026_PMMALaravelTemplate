<?php

namespace App\Http\Controllers;

use App\Models\ServiceCategory;
use App\Models\Ticket;
use App\Models\TicketUpdate;
use Illuminate\Http\Request;

class QueueController extends Controller
{
    public function public() { return view('queue', ['private' => false, 'dataUrl' => route('queue.data')]); }
    public function staff() { return view('queue', ['private' => true, 'dataUrl' => route('dashboard.queue.data')]); }

    public function data(Request $request)
    {
        $private = $request->user()?->is_staff === true;
        $tickets = Ticket::query()
            ->with(['technician:id,name', 'department:id,name', 'serviceCategory:id,slug,title', 'latestUpdate'])
            ->whereIn('status', ['Open', 'In Progress', 'Resolved'])
            ->oldest('created_at')->oldest('id')->get();
        $categories = ServiceCategory::where('is_active', true)->orderBy('id')->get(['slug', 'title'])->values();
        $groups = $categories->map(fn ($category) => ['slug' => $category->slug, 'title' => $category->title])->all();
        $known = $categories->pluck('slug')->all();
        $rows = [];
        foreach ($tickets as $ticket) {
            $category = $ticket->serviceCategory?->slug ?: $ticket->category;
            if (!in_array($category, $known, true)) {
                $groups[] = ['slug' => $category ?: 'other', 'title' => $ticket->serviceCategory?->title ?: ServiceCategory::label((string) $category)];
                $known[] = $category;
            }
            $rows[] = ['id' => $ticket->id, 'reference' => $ticket->reference, 'subject' => $ticket->subject, 'department' => $ticket->department?->name ?: 'General Support', 'category' => $category ?: 'other', 'status' => $ticket->status, 'priority' => $ticket->priority, 'technician' => $ticket->technician?->name, 'updated_at' => optional($ticket->updated_at)->toIso8601String(), 'latest_update' => $ticket->latestUpdate?->summary];
        }
        $updates = TicketUpdate::query()->with(['ticket:id,reference,technician_id', 'ticket.technician:id,name'])->latest('created_at')->limit(12)->get()->map(fn ($update) => ['reference' => $update->ticket?->reference, 'summary' => $update->summary, 'technician' => $update->ticket?->technician?->name ?: 'Unassigned', 'created_at' => optional($update->created_at)->toIso8601String()])->filter(fn ($update) => $update['reference'])->values();
        $counts = collect(['Open', 'In Progress', 'Resolved'])->mapWithKeys(fn ($status) => [$status => collect($rows)->where('status', $status)->count()]);
        return response()->json(['server_time' => now()->toIso8601String(), 'categories' => $groups, 'tickets' => $rows, 'updates' => $updates, 'counts' => $counts, 'private' => $private]);
    }
}
