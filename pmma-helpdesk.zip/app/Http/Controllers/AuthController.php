<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\Str;
use Illuminate\Validation\ValidationException;

class AuthController extends Controller
{
    public function showLogin(Request $request)
    {
        return response()->view('auth.login')
            ->header('Cache-Control', 'no-store, no-cache, must-revalidate, max-age=0')
            ->header('Pragma', 'no-cache');
    }

    public function login(Request $request)
    {
        $data = $request->validate(['email' => 'required|string|max:254', 'password' => 'required|string|max:1024']);
        $data['email'] = trim($data['email']);
        $key = 'staff-login:'.hash('sha256', Str::lower($data['email']).'|'.$request->ip());
        if (RateLimiter::tooManyAttempts($key, 5)) {
            throw ValidationException::withMessages(['email' => 'Too many attempts. Try again in '.RateLimiter::availableIn($key).' seconds.']);
        }
        $field = filter_var($data['email'], FILTER_VALIDATE_EMAIL) ? 'email' : 'username';
        if (! Auth::attempt([$field => $data['email'], 'password' => $data['password'], 'is_staff' => true])) {
            RateLimiter::hit($key, 60);
            throw ValidationException::withMessages(['email' => 'The provided credentials do not match an authorized staff account.']);
        }
        RateLimiter::clear($key);
        $request->attributes->set('audit_success', true);
        $request->session()->regenerate();
        return redirect()->intended(route('dashboard'));
    }

    public function logout(Request $request)
    {
        $user = $request->user();
        $returnUrl = url()->previous();
        $returnHost = parse_url($returnUrl, PHP_URL_HOST);
        $currentHost = parse_url($request->url(), PHP_URL_HOST);
        $keepIntended = $returnHost === $currentHost
            && str_starts_with(parse_url($returnUrl, PHP_URL_PATH) ?? '', '/dashboard')
            && !str_ends_with(parse_url($returnUrl, PHP_URL_PATH) ?? '', '/login')
            && !str_ends_with(parse_url($returnUrl, PHP_URL_PATH) ?? '', '/logout');
        $request->attributes->set('audit_actor', ['id' => $user->id, 'name' => $user->name, 'login' => $user->username ?: $user->email]);
        Auth::logout();
        $request->session()->invalidate();
        $request->session()->regenerateToken();
        if ($keepIntended) redirect()->setIntendedUrl($returnUrl);
        return redirect()->route('login');
    }
}
