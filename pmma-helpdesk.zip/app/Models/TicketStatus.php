<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class TicketStatus extends Model
{
    protected $fillable = ['code', 'label', 'sort_order', 'is_terminal', 'is_active'];
    protected function casts(): array { return ['is_terminal' => 'boolean', 'is_active' => 'boolean']; }
}
