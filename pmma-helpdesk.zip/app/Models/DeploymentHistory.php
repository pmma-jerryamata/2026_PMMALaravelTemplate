<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;

class DeploymentHistory extends Model
{
    protected $fillable = ['release', 'summary', 'environment', 'deployed_by', 'deployed_by_name', 'changed_files', 'deployed_at'];
    protected $casts = ['changed_files' => 'array', 'deployed_at' => 'datetime'];
    public function user() { return $this->belongsTo(User::class, 'deployed_by'); }
}
