<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;

class TicketUpdate extends Model
{
    protected static function booted(): void
    {
        static::creating(function (TicketUpdate $update) {
            // Use the app clock, matching tickets, instead of the database session timezone.
            if ($update->created_at === null) $update->created_at = now();
        });
    }

    public $timestamps = false;
    protected $fillable = ['user_id', 'actor_name', 'event', 'summary', 'action_taken', 'changes', 'created_at'];
    protected function casts(): array { return ['changes' => 'array', 'created_at' => 'datetime']; }
    public function ticket(): BelongsTo { return $this->belongsTo(Ticket::class); }
}
