<?php

namespace App\Console\Commands;

use App\Models\DeploymentHistory;
use Illuminate\Console\Command;

class RecordDeployment extends Command
{
    protected $signature = 'deployment:record {release} {summary} {--files=*} {--by=}';
    protected $description = 'Record a production deployment in deployment history';

    public function handle(): int
    {
        $user = auth()->user();
        DeploymentHistory::create([
            'release' => $this->argument('release'),
            'summary' => $this->argument('summary'),
            'environment' => app()->environment(),
            'deployed_by' => $user?->id,
            'deployed_by_name' => $this->option('by') ?: $user?->name ?: 'SSH deployment',
            'changed_files' => $this->option('files') ?: null,
            'deployed_at' => now(),
        ]);
        $this->info('Deployment recorded.');
        return self::SUCCESS;
    }
}
