/*M!999999\- enable the sandbox mode */ 
-- MariaDB dump 10.19-11.8.6-MariaDB, for debian-linux-gnu (x86_64)
--
-- Host: db5021765779.hosting-data.io    Database: dbs16280987
-- ------------------------------------------------------
-- Server version	11.8.8-MariaDB-log

/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;
/*!40103 SET @OLD_TIME_ZONE=@@TIME_ZONE */;
/*!40103 SET TIME_ZONE='+00:00' */;
/*!40014 SET @OLD_UNIQUE_CHECKS=@@UNIQUE_CHECKS, UNIQUE_CHECKS=0 */;
/*!40014 SET @OLD_FOREIGN_KEY_CHECKS=@@FOREIGN_KEY_CHECKS, FOREIGN_KEY_CHECKS=0 */;
/*!40101 SET @OLD_SQL_MODE=@@SQL_MODE, SQL_MODE='NO_AUTO_VALUE_ON_ZERO' */;
/*M!100616 SET @OLD_NOTE_VERBOSITY=@@NOTE_VERBOSITY, NOTE_VERBOSITY=0 */;

--
-- Table structure for table `activity_logs`
--

DROP TABLE IF EXISTS `activity_logs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `activity_logs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `actor_name` varchar(255) NOT NULL,
  `actor_login` varchar(255) DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `operation` varchar(120) NOT NULL,
  `outcome` varchar(20) NOT NULL,
  `method` varchar(10) NOT NULL,
  `path` varchar(500) NOT NULL,
  `status_code` smallint(5) unsigned NOT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `activity_logs_user_id_foreign` (`user_id`),
  KEY `activity_logs_actor_name_index` (`actor_name`),
  KEY `activity_logs_actor_login_index` (`actor_login`),
  KEY `activity_logs_ip_address_index` (`ip_address`),
  KEY `activity_logs_operation_index` (`operation`),
  KEY `activity_logs_outcome_index` (`outcome`),
  KEY `activity_logs_created_at_index` (`created_at`),
  CONSTRAINT `activity_logs_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB AUTO_INCREMENT=29 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `activity_logs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `activity_logs` WRITE;
/*!40000 ALTER TABLE `activity_logs` DISABLE KEYS */;
INSERT INTO `activity_logs` VALUES
(1,NULL,'Guest / Requestee',NULL,'127.0.0.1','home.view','success','GET','//',200,'{\"route\":\"home\"}','2026-10-28 03:24:41'),
(2,NULL,'Guest / Requestee',NULL,'2607:f1c0:5ff:5f:74:208:59:132','home.view','success','GET','//',200,'{\"route\":\"home\"}','2026-10-28 03:28:56'),
(3,NULL,'Guest / Requestee',NULL,'2607:f1c0:5ff:5f:74:208:59:132','home.view','success','GET','//',200,'{\"route\":\"home\"}','2026-10-28 03:29:03'),
(4,NULL,'Guest / Requestee',NULL,'2607:f1c0:5ff:5f:74:208:59:132','login.view','success','GET','/login',200,'{\"route\":\"login\"}','2026-10-28 03:29:09'),
(5,NULL,'Guest / Requestee',NULL,'2607:f1c0:5ff:5f:74:208:59:132','tickets.create.view','success','GET','/tickets/create',200,'{\"route\":\"tickets.create\"}','2026-10-28 03:29:09'),
(6,NULL,'Guest / Requestee',NULL,'2a09:bac5:d5d8:2e1e::498:85','login.view','success','GET','/login',200,'{\"route\":\"login\"}','2026-10-28 03:29:18'),
(7,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','auth.login','success','POST','/login',302,'{\"route\":\"login.submit\",\"submitted_fields\":[\"email\"]}','2026-10-28 03:29:24'),
(8,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','dashboard.view','success','GET','/dashboard',200,'{\"route\":\"dashboard\"}','2026-10-28 03:29:25'),
(9,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','dashboard.tickets.data.view','success','GET','/dashboard/tickets/data',200,'{\"route\":\"dashboard.tickets.data\"}','2026-10-28 03:29:27'),
(10,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','auth.logout','success','POST','/logout',302,'{\"route\":\"logout\",\"submitted_fields\":[]}','2026-10-28 03:29:32'),
(11,NULL,'Guest / Requestee',NULL,'2a09:bac5:d5d8:2e1e::498:85','login.view','success','GET','/login',200,'{\"route\":\"login\"}','2026-10-28 03:29:32'),
(12,NULL,'Guest / Requestee',NULL,'2a09:bac5:d5d8:2e1e::498:85','home.view','success','GET','//',200,'{\"route\":\"home\"}','2026-10-28 03:29:56'),
(13,NULL,'Guest / Requestee',NULL,'2a09:bac5:d5d8:2e1e::498:85','tickets.recent.data.view','success','GET','/tickets/recent/data',200,'{\"route\":\"tickets.recent.data\"}','2026-10-28 03:29:58'),
(14,NULL,'Guest / Requestee',NULL,'2a09:bac5:d5d8:2e1e::498:85','login.view','success','GET','/login',200,'{\"route\":\"login\"}','2026-10-28 03:30:03'),
(15,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','auth.login','success','POST','/login',302,'{\"route\":\"login.submit\",\"submitted_fields\":[\"email\"]}','2026-10-28 03:30:07'),
(16,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','dashboard.view','success','GET','/dashboard',200,'{\"route\":\"dashboard\"}','2026-10-28 03:30:07'),
(17,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','dashboard.tickets.data.view','success','GET','/dashboard/tickets/data',200,'{\"route\":\"dashboard.tickets.data\"}','2026-10-28 03:30:09'),
(18,NULL,'Guest / Requestee',NULL,'2a09:bac5:d5d8:2e1e::498:85','login.view','success','GET','/login',200,'{\"route\":\"login\"}','2026-10-28 03:31:18'),
(19,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','auth.login','success','POST','/login',302,'{\"route\":\"login.submit\",\"submitted_fields\":[\"email\"]}','2026-10-28 03:31:24'),
(20,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','dashboard.view','success','GET','/dashboard',200,'{\"route\":\"dashboard\"}','2026-10-28 03:31:25'),
(21,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','dashboard.tickets.data.view','success','GET','/dashboard/tickets/data',200,'{\"route\":\"dashboard.tickets.data\"}','2026-10-28 03:31:26'),
(22,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','dashboard.view','success','GET','/dashboard',200,'{\"route\":\"dashboard\"}','2026-10-28 03:33:25'),
(23,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','dashboard.tickets.data.view','success','GET','/dashboard/tickets/data',200,'{\"route\":\"dashboard.tickets.data\"}','2026-10-28 03:33:27'),
(24,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','auth.logout','success','POST','/logout',302,'{\"route\":\"logout\",\"submitted_fields\":[]}','2026-10-28 03:33:31'),
(25,NULL,'Guest / Requestee',NULL,'2a09:bac5:d5d8:2e1e::498:85','login.view','success','GET','/login',200,'{\"route\":\"login\"}','2026-10-28 03:33:32'),
(26,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','auth.login','success','POST','/login',302,'{\"route\":\"login.submit\",\"submitted_fields\":[\"email\"]}','2026-10-28 03:33:37'),
(27,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','dashboard.view','success','GET','/dashboard',200,'{\"route\":\"dashboard\"}','2026-10-28 03:33:38'),
(28,1,'Jerry','jerry','2a09:bac5:d5d8:2e1e::498:85','dashboard.tickets.data.view','success','GET','/dashboard/tickets/data',200,'{\"route\":\"dashboard.tickets.data\"}','2026-10-28 03:33:38');
/*!40000 ALTER TABLE `activity_logs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache`
--

DROP TABLE IF EXISTS `cache`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache` (
  `key` varchar(255) NOT NULL,
  `value` mediumtext NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache` WRITE;
/*!40000 ALTER TABLE `cache` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `cache_locks`
--

DROP TABLE IF EXISTS `cache_locks`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `cache_locks` (
  `key` varchar(255) NOT NULL,
  `owner` varchar(255) NOT NULL,
  `expiration` int(11) NOT NULL,
  PRIMARY KEY (`key`),
  KEY `cache_locks_expiration_index` (`expiration`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `cache_locks`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `cache_locks` WRITE;
/*!40000 ALTER TABLE `cache_locks` DISABLE KEYS */;
/*!40000 ALTER TABLE `cache_locks` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `departments`
--

DROP TABLE IF EXISTS `departments`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `departments` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `code` varchar(255) DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `departments_name_unique` (`name`),
  UNIQUE KEY `departments_code_unique` (`code`)
) ENGINE=InnoDB AUTO_INCREMENT=46 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `departments`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `departments` WRITE;
/*!40000 ALTER TABLE `departments` DISABLE KEYS */;
INSERT INTO `departments` VALUES
(1,'ITSU: Info. Technology Services Unit','ITSU',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(2,'Other Department / Office','OTHER',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(3,'Students',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(4,'Accounting Unit',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(5,'Assessment Unit',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(6,'BAC: Bids and Awards Committee','BAC',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(7,'BMO: Business Management Office','BMO',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(8,'BOA: Admissions Office','BOA',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(9,'Board Secretary',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(10,'Budget Unit',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(11,'CAO: Chief Administrative Office','CAO',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(12,'Cashier Unit',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(13,'CME: College of Marine Engineering','CME',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(14,'CMT: College of Marine Transportation','CMT',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(15,'COA: Commission on Audit','COA',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(16,'DMA: Department of Midshipmen Affairs','DMA',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(17,'DNST: Dept. of Naval Science and Tactics','DNST',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(18,'Dormitory Unit',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(19,'DRDE: Dept. of Research and Development','DRDE',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(20,'DST: Department of Shipboard Training','DST',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(21,'Graduate School',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(22,'GSU: General Services Unit','GSU',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(23,'Guidance Unit',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(24,'HRMO: Human Resource Management Office','HRMO',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(25,'Internal Audit',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(26,'IRO: International Relations Office','IRO',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(27,'Legal Unit',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(28,'Library Unit',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(29,'Medical and Dental Unit',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(30,'Mess Unit',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(31,'MSU: Maritime Simulation Unit','MSU',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(32,'OAS-Administration and Finance',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(33,'OAS-ATRE',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(34,'OOS: Office of the Superintendent','OOS',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(35,'PAMRU: Public Affairs and Media Relations Unit','PAMRU',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(36,'PDO: Project Development Office','PDO',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(37,'Planning Office',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(38,'QAO: Quality Assurance Office','QAO',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(39,'Records Unit, DPO',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(40,'Registrar Office',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(41,'Safety Unit',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(42,'Security Unit',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(43,'SPMU: Supply and Property Mngmt. Unit','SPMU',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(44,'Training Center',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(45,'Transportation Unit',NULL,1,'2026-10-28 07:24:20','2026-10-28 07:24:20');
/*!40000 ALTER TABLE `departments` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `failed_jobs`
--

DROP TABLE IF EXISTS `failed_jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `failed_jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `uuid` varchar(255) NOT NULL,
  `connection` text NOT NULL,
  `queue` text NOT NULL,
  `payload` longtext NOT NULL,
  `exception` longtext NOT NULL,
  `failed_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  UNIQUE KEY `failed_jobs_uuid_unique` (`uuid`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `failed_jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `failed_jobs` WRITE;
/*!40000 ALTER TABLE `failed_jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `failed_jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `job_batches`
--

DROP TABLE IF EXISTS `job_batches`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `job_batches` (
  `id` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `total_jobs` int(11) NOT NULL,
  `pending_jobs` int(11) NOT NULL,
  `failed_jobs` int(11) NOT NULL,
  `failed_job_ids` longtext NOT NULL,
  `options` mediumtext DEFAULT NULL,
  `cancelled_at` int(11) DEFAULT NULL,
  `created_at` int(11) NOT NULL,
  `finished_at` int(11) DEFAULT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `job_batches`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `job_batches` WRITE;
/*!40000 ALTER TABLE `job_batches` DISABLE KEYS */;
/*!40000 ALTER TABLE `job_batches` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `jobs`
--

DROP TABLE IF EXISTS `jobs`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `jobs` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `queue` varchar(255) NOT NULL,
  `payload` longtext NOT NULL,
  `attempts` tinyint(3) unsigned NOT NULL,
  `reserved_at` int(10) unsigned DEFAULT NULL,
  `available_at` int(10) unsigned NOT NULL,
  `created_at` int(10) unsigned NOT NULL,
  PRIMARY KEY (`id`),
  KEY `jobs_queue_index` (`queue`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `jobs`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `jobs` WRITE;
/*!40000 ALTER TABLE `jobs` DISABLE KEYS */;
/*!40000 ALTER TABLE `jobs` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `migrations`
--

DROP TABLE IF EXISTS `migrations`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `migrations` (
  `id` int(10) unsigned NOT NULL AUTO_INCREMENT,
  `migration` varchar(255) NOT NULL,
  `batch` int(11) NOT NULL,
  PRIMARY KEY (`id`)
) ENGINE=InnoDB AUTO_INCREMENT=16 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `migrations`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `migrations` WRITE;
/*!40000 ALTER TABLE `migrations` DISABLE KEYS */;
INSERT INTO `migrations` VALUES
(1,'0001_01_01_000000_create_users_table',1),
(2,'0001_01_01_000001_create_cache_table',1),
(3,'0001_01_01_000002_create_jobs_table',1),
(4,'2026_10_27_000000_create_tickets_table',1),
(5,'2026_10_27_010000_add_helpdesk_profiles_and_departments',1),
(6,'2026_10_27_020000_add_staff_access_to_users',1),
(7,'2026_10_27_030000_add_username_to_users',1),
(8,'2026_10_27_040000_create_service_categories',1),
(9,'2026_10_27_050000_create_system_settings',1),
(10,'2026_10_27_060000_create_activity_logs',1),
(11,'2026_10_27_070000_create_ticket_updates',1),
(12,'2026_10_27_080000_add_ticket_query_indexes',1),
(13,'2026_10_28_000000_populate_department_directory',1),
(14,'2026_10_28_010000_normalize_department_names',1),
(15,'2026_10_28_020000_create_ticket_reference_counters',1);
/*!40000 ALTER TABLE `migrations` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `password_reset_tokens`
--

DROP TABLE IF EXISTS `password_reset_tokens`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `password_reset_tokens` (
  `email` varchar(255) NOT NULL,
  `token` varchar(255) NOT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`email`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `password_reset_tokens`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `password_reset_tokens` WRITE;
/*!40000 ALTER TABLE `password_reset_tokens` DISABLE KEYS */;
/*!40000 ALTER TABLE `password_reset_tokens` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `service_categories`
--

DROP TABLE IF EXISTS `service_categories`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `service_categories` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `slug` varchar(255) NOT NULL,
  `title` varchar(255) NOT NULL,
  `icon` varchar(255) NOT NULL DEFAULT 'life-preserver',
  `description` text NOT NULL,
  `items` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL CHECK (json_valid(`items`)),
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `service_categories_slug_unique` (`slug`)
) ENGINE=InnoDB AUTO_INCREMENT=7 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `service_categories`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `service_categories` WRITE;
/*!40000 ALTER TABLE `service_categories` DISABLE KEYS */;
INSERT INTO `service_categories` VALUES
(1,'internet-network','Internet/Network Connectivity','wifi','Get help with slow internet, dropped connections, Wi-Fi dead zones, and network access.','[\"Slow or unavailable internet\",\"Wi-Fi connection issues\",\"Network access and dropped connections\"]',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(2,'pc-laptop','PC/Laptop Troubleshooting','laptop','Resolve freezing screens, error messages, startup problems, and computer performance issues.','[\"Computer freezing or crashing\",\"Startup and error messages\",\"PC and laptop diagnostics\"]',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(3,'printer-peripherals','Printer and Other Peripherals Repair','printer','Request assistance with printers, scanners, external drives, and other computer peripherals.','[\"Printer and scanner issues\",\"External drive problems\",\"Peripheral connection and repair\"]',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(4,'software','Software Installation and Troubleshooting','window-stack','Get assistance installing software or fixing errors and issues with your current programs.','[\"Software installation and setup\",\"Application errors\",\"Software updates and troubleshooting\"]',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(5,'hardware','Hardware Installation and Troubleshooting','tools','Get help setting up equipment, installing components, and diagnosing hardware problems.','[\"Hardware installation and setup\",\"Component diagnostics\",\"Equipment troubleshooting\"]',1,'2026-10-28 07:24:20','2026-10-28 07:24:20'),
(6,'others','Others','life-preserver','Have a technical concern that does not fit another category? Tell us what you need help with.','[\"Other technical concerns\",\"Help choosing the right support\",\"General IT assistance\"]',1,'2026-10-28 07:24:20','2026-10-28 07:24:20');
/*!40000 ALTER TABLE `service_categories` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `sessions`
--

DROP TABLE IF EXISTS `sessions`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `sessions` (
  `id` varchar(255) NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `ip_address` varchar(45) DEFAULT NULL,
  `user_agent` text DEFAULT NULL,
  `payload` longtext NOT NULL,
  `last_activity` int(11) NOT NULL,
  PRIMARY KEY (`id`),
  KEY `sessions_user_id_index` (`user_id`),
  KEY `sessions_last_activity_index` (`last_activity`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `sessions`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `sessions` WRITE;
/*!40000 ALTER TABLE `sessions` DISABLE KEYS */;
/*!40000 ALTER TABLE `sessions` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `system_settings`
--

DROP TABLE IF EXISTS `system_settings`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `system_settings` (
  `key` varchar(255) NOT NULL,
  `value` text NOT NULL,
  PRIMARY KEY (`key`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `system_settings`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `system_settings` WRITE;
/*!40000 ALTER TABLE `system_settings` DISABLE KEYS */;
/*!40000 ALTER TABLE `system_settings` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `technicians`
--

DROP TABLE IF EXISTS `technicians`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `technicians` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `department_id` bigint(20) unsigned DEFAULT NULL,
  `employee_number` varchar(255) DEFAULT NULL,
  `name` varchar(120) NOT NULL,
  `email` varchar(255) NOT NULL,
  `phone` varchar(40) DEFAULT NULL,
  `position` varchar(255) DEFAULT NULL,
  `specialization` varchar(255) DEFAULT NULL,
  `photo_path` varchar(255) DEFAULT NULL,
  `bio` text DEFAULT NULL,
  `is_active` tinyint(1) NOT NULL DEFAULT 1,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `technicians_email_unique` (`email`),
  UNIQUE KEY `technicians_user_id_unique` (`user_id`),
  UNIQUE KEY `technicians_employee_number_unique` (`employee_number`),
  KEY `technicians_department_id_foreign` (`department_id`),
  CONSTRAINT `technicians_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`) ON DELETE SET NULL,
  CONSTRAINT `technicians_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `technicians`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `technicians` WRITE;
/*!40000 ALTER TABLE `technicians` DISABLE KEYS */;
/*!40000 ALTER TABLE `technicians` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ticket_reference_counters`
--

DROP TABLE IF EXISTS `ticket_reference_counters`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_reference_counters` (
  `year` smallint(5) unsigned NOT NULL,
  `office` varchar(3) NOT NULL,
  `last_number` bigint(20) unsigned NOT NULL DEFAULT 0,
  PRIMARY KEY (`year`,`office`)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_reference_counters`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ticket_reference_counters` WRITE;
/*!40000 ALTER TABLE `ticket_reference_counters` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_reference_counters` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `ticket_updates`
--

DROP TABLE IF EXISTS `ticket_updates`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `ticket_updates` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `ticket_id` bigint(20) unsigned NOT NULL,
  `user_id` bigint(20) unsigned DEFAULT NULL,
  `actor_name` varchar(255) NOT NULL,
  `event` varchar(40) NOT NULL,
  `summary` text NOT NULL,
  `action_taken` text DEFAULT NULL,
  `changes` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`changes`)),
  `created_at` timestamp NOT NULL DEFAULT current_timestamp(),
  PRIMARY KEY (`id`),
  KEY `ticket_updates_user_id_foreign` (`user_id`),
  KEY `ticket_updates_ticket_id_created_at_index` (`ticket_id`,`created_at`),
  CONSTRAINT `ticket_updates_ticket_id_foreign` FOREIGN KEY (`ticket_id`) REFERENCES `tickets` (`id`) ON DELETE CASCADE,
  CONSTRAINT `ticket_updates_user_id_foreign` FOREIGN KEY (`user_id`) REFERENCES `users` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `ticket_updates`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `ticket_updates` WRITE;
/*!40000 ALTER TABLE `ticket_updates` DISABLE KEYS */;
/*!40000 ALTER TABLE `ticket_updates` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `tickets`
--

DROP TABLE IF EXISTS `tickets`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `tickets` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `reference` varchar(255) NOT NULL,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `category` varchar(255) NOT NULL,
  `subject` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `priority` varchar(255) NOT NULL DEFAULT 'normal',
  `status` varchar(255) NOT NULL DEFAULT 'Open',
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `department_id` bigint(20) unsigned DEFAULT NULL,
  `technician_id` bigint(20) unsigned DEFAULT NULL,
  PRIMARY KEY (`id`),
  UNIQUE KEY `tickets_reference_unique` (`reference`),
  KEY `tickets_technician_id_foreign` (`technician_id`),
  KEY `tickets_created_page` (`created_at`,`id`),
  KEY `tickets_status_created` (`status`,`created_at`),
  KEY `tickets_department_created` (`department_id`,`created_at`),
  KEY `tickets_category_created` (`category`,`created_at`),
  CONSTRAINT `tickets_department_id_foreign` FOREIGN KEY (`department_id`) REFERENCES `departments` (`id`),
  CONSTRAINT `tickets_technician_id_foreign` FOREIGN KEY (`technician_id`) REFERENCES `technicians` (`id`) ON DELETE SET NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `tickets`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `tickets` WRITE;
/*!40000 ALTER TABLE `tickets` DISABLE KEYS */;
/*!40000 ALTER TABLE `tickets` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;

--
-- Table structure for table `users`
--

DROP TABLE IF EXISTS `users`;
/*!40101 SET @saved_cs_client     = @@character_set_client */;
/*!40101 SET character_set_client = utf8mb4 */;
CREATE TABLE `users` (
  `id` bigint(20) unsigned NOT NULL AUTO_INCREMENT,
  `name` varchar(255) NOT NULL,
  `email` varchar(255) NOT NULL,
  `email_verified_at` timestamp NULL DEFAULT NULL,
  `password` varchar(255) NOT NULL,
  `remember_token` varchar(100) DEFAULT NULL,
  `created_at` timestamp NULL DEFAULT NULL,
  `updated_at` timestamp NULL DEFAULT NULL,
  `is_staff` tinyint(1) NOT NULL DEFAULT 0,
  `username` varchar(255) DEFAULT NULL,
  `is_dev_admin` tinyint(1) NOT NULL DEFAULT 0,
  PRIMARY KEY (`id`),
  UNIQUE KEY `users_email_unique` (`email`),
  UNIQUE KEY `users_username_unique` (`username`)
) ENGINE=InnoDB AUTO_INCREMENT=2 DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;
/*!40101 SET character_set_client = @saved_cs_client */;

--
-- Dumping data for table `users`
--

SET @OLD_AUTOCOMMIT=@@AUTOCOMMIT, @@AUTOCOMMIT=0;
LOCK TABLES `users` WRITE;
/*!40000 ALTER TABLE `users` DISABLE KEYS */;
INSERT INTO `users` VALUES
(1,'Jerry','jerry@helpdesk.invalid',NULL,'$2y$12$QpADj7nnc2LJMeWO2FUYu.lPY0t9.tJHYGsAd7kTB4DnsrpK6Bv.W',NULL,'2026-10-28 07:27:41','2026-10-28 07:27:41',1,'jerry',0);
/*!40000 ALTER TABLE `users` ENABLE KEYS */;
UNLOCK TABLES;
COMMIT;
SET AUTOCOMMIT=@OLD_AUTOCOMMIT;
/*!40103 SET TIME_ZONE=@OLD_TIME_ZONE */;

/*!40101 SET SQL_MODE=@OLD_SQL_MODE */;
/*!40014 SET FOREIGN_KEY_CHECKS=@OLD_FOREIGN_KEY_CHECKS */;
/*!40014 SET UNIQUE_CHECKS=@OLD_UNIQUE_CHECKS */;
/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
/*M!100616 SET NOTE_VERBOSITY=@OLD_NOTE_VERBOSITY */;

-- Dump completed on 2026-10-27 23:56:23
