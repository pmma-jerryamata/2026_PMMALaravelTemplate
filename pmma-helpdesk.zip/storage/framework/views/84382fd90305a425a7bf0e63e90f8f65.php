<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#10264b">
    <title><?php echo $__env->yieldContent('title', 'Staff Login'); ?> | <?php echo e($systemSettings['app_name']); ?></title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/pmma-seal.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/accessibility.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/pmma.css')); ?>">
</head>
<body class="auth-page">
    <main class="auth-main" id="main-content">
        <?php echo $__env->yieldContent('content'); ?>
    </main>
<script>
document.querySelector('.password-toggle')?.addEventListener('click', function () {
    const input = document.getElementById('password');
    const visible = input.type === 'password';
    input.type = visible ? 'text' : 'password';
    this.setAttribute('aria-pressed', String(visible));
    this.setAttribute('aria-label', visible ? 'Hide Password' : 'Show Password');
    this.querySelector('i').className = visible ? 'bi bi-eye-slash' : 'bi bi-eye';
});
</script>
</body>
</html>
<?php /**PATH /homepages/40/d4299593833/htdocs/pmma-helpdesk-app/resources/views/layouts/auth.blade.php ENDPATH**/ ?>