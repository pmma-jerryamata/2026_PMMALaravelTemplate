<?php $__currentLoopData = $recentTickets; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $recent): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><tr><td><?php echo e($recent->reference); ?></td><td><?php echo e($recent->subject); ?></td><td><?php echo e($recent->department?->name ?? 'Not Specified'); ?></td><td><span class="dashboard-status" data-status="<?php echo e($recent->status); ?>"><?php echo e($recent->status); ?></span></td><td><?php echo $__env->make('portal.partials.last-action', ['ticket' => $recent], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></td><td><button type="button" class="btn btn-secondary btn-sm icon-action" data-public-timeline-url="<?php echo e(route('tickets.timeline', $recent->reference)); ?>" aria-label="View Timeline" title="View Timeline"><?php if (isset($component)) { $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-icon','data' => ['name' => 'clock-history']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'clock-history']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $attributes = $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $component = $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?></button></td></tr><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH /homepages/40/d4299593833/htdocs/pmma-helpdesk-app/resources/views/portal/partials/recent-ticket-rows.blade.php ENDPATH**/ ?>