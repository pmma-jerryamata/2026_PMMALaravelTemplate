<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#10264b">
    <meta name="description" content="PMMA Ticket System — submit campus service requests and track your support tickets.">
    <title><?php echo $__env->yieldContent('title', 'Home'); ?> | <?php echo e($systemSettings['app_name']); ?></title>
    <link rel="icon" type="image/png" href="<?php echo e(asset('assets/images/pmma-seal.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/responsive.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/accessibility.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/footer.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/pmma.css')); ?>?v=<?php echo e(filemtime(public_path('assets/css/pmma.css'))); ?>">
    <script src="<?php echo e(asset('assets/js/portal.js')); ?>?v=<?php echo e(filemtime(public_path('assets/js/portal.js'))); ?>" defer></script>
    <?php echo $__env->yieldPushContent('page-assets'); ?>
</head>
<body>
<a href="#main-content" class="skip-link">Skip to main content</a>
<div class="hotline-bar"><div class="container portal-topbar"><span><i class="bi bi-shield-check" aria-hidden="true"></i> Philippine Merchant Marine Academy</span><a href="<?php echo e(route('track')); ?>">Already submitted a request? Track Your Ticket <i class="bi bi-arrow-right" aria-hidden="true"></i></a></div></div>
<header class="site-header"><div class="container header-inner">
    <a class="portal-brand" href="<?php echo e(route('home')); ?>" aria-label="PMMA Helpdesk home"><img class="brand-seal" src="<?php echo e(asset('assets/images/pmma-seal.png')); ?>" alt="PMMA seal" width="64" height="64"><span><strong><?php echo e($systemSettings['app_name']); ?></strong><small><?php echo e($systemSettings['portal_subtitle']); ?></small></span></a>
    <nav id="main-navigation" class="main-nav" aria-label="Main navigation"><ul>
        <?php $__currentLoopData = ['home' => 'Home', 'services' => 'Services', 'queue' => 'Live Queue', 'track' => 'Track Ticket', 'faq' => 'FAQs', 'contact' => 'Contact']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $route => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <li><a href="<?php echo e(route($route)); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['active' => request()->routeIs($route, $route.'.*')]); ?>" <?php if(request()->routeIs($route, $route.'.*')): ?> aria-current="page" <?php endif; ?>><?php echo e($label); ?></a></li>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <li class="nav-account"><a class="btn btn-primary nav-login ui-action" aria-label="<?php echo e(auth()->check() ? 'Dashboard' : 'Login'); ?>" title="<?php echo e(auth()->check() ? 'Dashboard' : 'Login'); ?>" href="<?php echo e(auth()->check() ? route('dashboard') : route('login')); ?>" <?php if(request()->routeIs('login', 'dashboard', 'dashboard.*')): ?> aria-current="page" <?php endif; ?>><i class="bi bi-<?php echo e(auth()->check() ? 'grid' : 'box-arrow-in-right'); ?>" aria-hidden="true"></i><span><?php echo e(auth()->check() ? 'Dashboard' : 'Login'); ?></span></a></li>
    </ul></nav>
    <button type="button" class="mobile-menu-toggle btn btn-secondary" aria-controls="main-navigation" aria-expanded="false" aria-label="Toggle navigation"><i class="bi bi-list" aria-hidden="true"></i></button>
</div></header>
<div class="info-bar"><div class="container portal-infobar"><span><span class="status-dot"></span> <?php echo e($systemSettings['support_tagline']); ?></span><span class="portal-clock"><span id="ph-clock" data-sync-url="<?php echo e(route('time')); ?>">Syncing time…</span><span class="clock-label">PST</span></span></div></div>
<main id="main-content">
<?php if($errors->any()): ?><div class="container"><div class="portal-alert error" role="alert"><strong>Please check the following:</strong><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div></div><?php endif; ?>
<?php echo $__env->yieldContent('content'); ?>
</main>
<footer class="site-footer"><div class="container"><div class="footer-main-new">
    <div class="footer-brand"><a class="portal-brand footer-pmma" href="<?php echo e(route('home')); ?>"><img class="brand-seal" src="<?php echo e(asset('assets/images/pmma-seal.png')); ?>" alt="PMMA seal" width="64" height="64" loading="lazy"><span><strong><?php echo e($systemSettings['app_name']); ?></strong><small><?php echo e($systemSettings['portal_subtitle']); ?></small></span></a><p class="footer-tagline">A simpler way to connect.<br>A better way to get support.</p></div>
    <div class="footer-column"><h4>Quick Links</h4><ul class="footer-links-new"><li><a href="<?php echo e(route('services')); ?>">Browse Services</a></li><li><a href="<?php echo e(route('tickets.create')); ?>">Submit a Ticket</a></li><li><a href="<?php echo e(route('track')); ?>">Track Your Ticket</a></li></ul></div>
    <div class="footer-column"><h4>Help & Resources</h4><ul class="footer-links-new"><li><a href="<?php echo e(route('faq')); ?>">Frequently Asked Questions</a></li><li><a href="<?php echo e(route('contact')); ?>">Contact & Support</a></li><li><a href="<?php echo e(route('privacy')); ?>">Privacy Notice</a></li></ul></div>
    <div class="footer-column"><h4>PMMA Service Portal</h4><p>For cadets, faculty, and staff.<br>Submit. Track. Stay informed.</p><a href="<?php echo e(route('tickets.create')); ?>" class="footer-contribute">How Can We Help? <i class="bi bi-arrow-right" aria-hidden="true"></i></a></div>
</div><div class="footer-bottom-new"><div class="footer-copyright"><span>&copy; <?php echo e(date('Y')); ?> <?php echo e($systemSettings['app_name']); ?>.</span><span><?php echo e($systemSettings['footer_credit']); ?></span></div></div></div></footer>
</body></html>
<?php /**PATH /homepages/40/d4299593833/htdocs/pmma-helpdesk-app/resources/views/layouts/portal.blade.php ENDPATH**/ ?>