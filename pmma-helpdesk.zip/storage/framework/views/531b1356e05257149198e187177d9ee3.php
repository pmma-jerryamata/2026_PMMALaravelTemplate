
<?php $__env->startSection('title', 'Dashboard'); ?>
<?php $__env->startSection('content'); ?>
<?php ($ticketOptions = ['storeUrl' => route('dashboard.tickets.store'), 'departments' => $departments, 'technicians' => $technicians, 'services' => $services, 'statuses' => $statuses]); ?>
<h1 class="sr-only">Dashboard</h1>
<section class="section bg-alt"><div class="container">
    <div class="dashboard-metrics"><?php $__currentLoopData = ['Total Tickets' => $counts->sum(), 'Open' => $counts->get('Open', 0), 'In Progress' => $counts->get('In Progress', 0), 'Resolved' => $counts->get('Resolved', 0), 'Active Technicians' => $technicianCount]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $label => $count): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><article class="metric-card"><span><?php echo e($label); ?></span><strong><?php echo e($count); ?></strong><small><?php echo e($label === 'Active Technicians' ? 'Available staff profiles' : 'All support requests'); ?></small></article><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
    <?php if(!request('status')): ?><?php echo $__env->make('dashboard.analytics', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php endif; ?>
    <div class="portal-panel dashboard-tickets"><div class="section-heading-row"><div><h2>Support Tickets</h2><p>Review requests, assign technicians, and keep statuses up to date.</p></div><button type="button" class="btn btn-primary ui-action" data-new-ticket>＋ <span>New Ticket</span></button></div>
        <div id="vue-ticket-dashboard" data-source="<?php echo e(route('dashboard.tickets.data')); ?>" data-options="<?php echo e(json_encode($ticketOptions)); ?>"></div>
    </div>
</div></section>
<?php $__env->stopSection(); ?>
<?php $__env->startPush('dashboard-data'); ?>
<script type="application/json" id="ticket-options"><?php echo json_encode($ticketOptions, 15, 512) ?></script>
<?php $__env->stopPush(); ?>

<?php echo $__env->make('layouts.dashboard', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /homepages/40/d4299593833/htdocs/pmma-helpdesk-app/resources/views/dashboard/index.blade.php ENDPATH**/ ?>