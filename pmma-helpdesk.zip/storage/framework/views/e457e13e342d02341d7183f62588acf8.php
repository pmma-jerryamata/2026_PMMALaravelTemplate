<?php $__env->startSection('title', 'Frequently Asked Questions'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('portal.partials.heading', ['title' => 'How Can We Help?', 'subtitle' => 'Answers to common questions about campus support and service requests.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<section class="section faq-section"><div class="container"><div class="faq-layout"><div class="faq-list"><div class="faq-list-heading"><span class="portal-eyebrow">HELP CENTER</span><h2>Tickets & Requests</h2><p>Select a question to view the answer.</p></div>
<?php $__currentLoopData = [
'How do I submit a ticket?' => 'Choose a service from the directory or click Submit a Ticket. Fill out your name, email, category, subject, priority, and a detailed description. After submission, save the reference number shown on the confirmation page.',
'How do I check the status of my ticket?' => 'Open Track Ticket and enter your reference number to see ticket details and the progress timeline.',
'What details should I include?' => 'Describe the issue, its location, the affected system or equipment, and any troubleshooting you have tried. Do not include passwords or sensitive credentials.',
'Which service category should I choose?' => 'Select the category closest to your concern. If you are unsure, choose Others and describe the assistance you need.',
'When will my concern be resolved?' => 'Resolution depends on the type and complexity of the concern. This portal does not guarantee a fixed response time. Check your ticket status for progress.',
'Will I receive an email confirmation?' => 'The portal currently provides your reference number on screen after submission. Automatic email notifications are not enabled. Save or copy your reference before leaving the page.',
'Should I submit a second ticket for the same concern?' => 'Check the status of your existing request first. Keeping one ticket per concern helps avoid duplicate requests.',
]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $question => $answer): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><details class="portal-faq"><summary><?php echo e($question); ?><i class="bi bi-plus-lg" aria-hidden="true"></i></summary><p><?php echo e($answer); ?></p></details><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></div>
<aside class="portal-cta faq-help"><div class="home-service-icon"><i class="bi bi-headset" aria-hidden="true"></i></div><div><h2>Still Need Assistance?</h2><p>Send us your concern so it can be recorded and tracked.</p></div><a href="<?php echo e(route('tickets.create')); ?>" class="btn btn-primary ui-action" aria-label="Submit a Ticket" title="Submit a Ticket"><?php if (isset($component)) { $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-icon','data' => ['name' => 'send']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'send']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $attributes = $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $component = $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?><span>Submit a Ticket</span></a><a class="faq-track-link" href="<?php echo e(route('track')); ?>">Track an Existing Ticket <i class="bi bi-arrow-right" aria-hidden="true"></i></a></aside></div></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /homepages/40/d4299593833/htdocs/pmma-helpdesk-app/resources/views/portal/faq.blade.php ENDPATH**/ ?>