<section class="dashboard-analytics" aria-labelledby="analytics-heading" data-analytics-url="<?php echo e(route('dashboard.analytics')); ?>">
    <div class="analytics-header"><div><h2 id="analytics-heading">Ticket Analytics</h2><p>Based on submission date · Philippine time · Weeks start Monday</p></div><div class="analytics-periods" role="group" aria-label="Analytics Time Period">
        <?php $__currentLoopData = ['day' => ['calendar-date', 'Day'], 'week' => ['calendar-week', 'Week'], 'month' => ['calendar-month', 'Month']]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $value => [$icon, $label]): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <button type="button" class="analytics-period" data-period="<?php echo e($value); ?>" aria-label="<?php echo e($label); ?>" title="Group by <?php echo e(strtolower($label)); ?>" aria-pressed="<?php echo e($analytics['period'] === $value ? 'true' : 'false'); ?>"><?php if (isset($component)) { $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-icon','data' => ['name' => $icon]] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => \Illuminate\View\Compilers\BladeCompiler::sanitizeComponentAttribute($icon)]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $attributes = $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $component = $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?><span><?php echo e($label); ?></span></button>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div></div>
    <p id="analytics-summary" class="analytics-summary" role="status"><?php echo e($analytics['total']); ?> tickets · <?php echo e($analytics['range']); ?> · <?php echo e(ucfirst($analytics['period'])); ?> view</p>
    <p class="analytics-filter-note">Graphs follow the status, department, category, and search filters below. Summary cards show all-time totals.</p>
    <div class="analytics-grid">
        <article class="portal-panel chart-card"><h3>Tickets by Concern Category</h3><p>Category mix across the selected time periods.</p><div class="chart-area"><canvas id="category-chart" role="img" aria-label="Ticket counts by concern category over time"></canvas></div></article>
        <article class="portal-panel chart-card"><h3>Tickets by Department</h3><p>Total requests per office within the date range.</p><div class="chart-area"><canvas id="department-chart" role="img" aria-label="Ticket counts by department"></canvas></div></article>
        <article class="portal-panel chart-card"><h3>Ticket Volume</h3><p>New requests per day, week, or month.</p><div class="chart-area"><canvas id="volume-chart" role="img" aria-label="Ticket volume over time"></canvas></div></article>
    </div>
    <p id="analytics-empty" <?php if($analytics['total'] > 0): ?> hidden <?php endif; ?>>No tickets in this date range for the selected filters.</p>
    <details class="analytics-data"><summary>View Chart Data</summary><div id="analytics-data-content"></div></details>
</section>
<?php $__env->startPush('dashboard-data'); ?>
<script type="application/json" id="analytics-initial"><?php echo json_encode($analytics, 15, 512) ?></script>
<?php $__env->stopPush(); ?>
<?php /**PATH /homepages/40/d4299593833/htdocs/pmma-helpdesk-app/resources/views/dashboard/analytics.blade.php ENDPATH**/ ?>