<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Live Ticket Queue | <?php echo e($systemSettings['app_name']); ?></title>
    <link rel="icon" href="<?php echo e(asset('assets/images/pmma-seal.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/pmma.css')); ?>?v=queue-13">
    <link rel="stylesheet" href="<?php echo e(asset('assets/icons/bootstrap-icons.css')); ?>">
</head>
<body class="queue-page">
<header class="queue-topbar"><div class="queue-header-row"><div class="queue-brand"><img src="<?php echo e(asset('assets/images/pmma-seal.png')); ?>" alt="PMMA seal"><span><strong><?php echo e($systemSettings['app_name']); ?></strong><small>PMMA SUPPORT OPERATIONS</small></span></div><div class="queue-clock"><strong id="queue-time">--</strong><small id="queue-date">PST</small></div></div></header>
<main id="queue-app" data-url="<?php echo e($dataUrl); ?>" data-private="<?php echo e($private ? '1' : '0'); ?>">
    <section class="queue-featured"><div class="now-serving"><div class="now-serving-label">NOW SERVING</div><div id="now-serving-ticket"><strong>Waiting for live queue...</strong></div></div><div class="next-in-line"><div class="next-label">NEXT IN LINE</div><div id="next-ticket"><strong>Waiting for tickets...</strong></div></div></section>
    <div class="queue-layout"><section class="queue-board" aria-live="polite"><div class="queue-columns">
        <?php $__currentLoopData = ['Open' => 'Open', 'In Progress' => 'In Progress', 'Resolved' => 'Resolved']; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $status => $label): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <article class="queue-column" data-column="<?php echo e($status); ?>"><header><h2><?php echo e($label); ?></h2><strong data-column-count="<?php echo e($status); ?>">0</strong></header><div class="queue-category-rows" data-status="<?php echo e($status); ?>"></div></article>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div></section><aside class="queue-sidebar"><div class="queue-side-heading"><h2>Recent Updates</h2><span>Live</span></div><div id="queue-updates"></div></aside></div>
</main>
<script>window.queueConfig={url:<?php echo json_encode($dataUrl, 15, 512) ?>,private:<?php echo json_encode($private, 15, 512) ?>};</script><script src="<?php echo e(asset('assets/js/queue.js')); ?>?v=queue-10"></script>
</body></html>
<?php /**PATH /homepages/40/d4299593833/htdocs/pmma-helpdesk-app/resources/views/queue.blade.php ENDPATH**/ ?>