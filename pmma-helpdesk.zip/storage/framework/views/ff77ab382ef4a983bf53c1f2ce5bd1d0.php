<?php ($lastAction = $ticket->latestAction); ?>
<?php ($lastUpdate = $ticket->latestUpdate); ?>
<div class="ticket-last-action">
    <span><?php echo e($lastAction ? \Illuminate\Support\Str::limit($lastAction->action_taken, 180) : ($lastUpdate && $lastUpdate->event !== 'created' ? $lastUpdate->summary : 'Awaiting technician action.')); ?></span>
    <?php if($lastAction || $lastUpdate): ?>
        <small><?php echo e(($lastAction ?? $lastUpdate)->created_at->timezone('Asia/Manila')->format('M d, Y · h:i A')); ?></small>
    <?php endif; ?>
</div>
<?php /**PATH /homepages/40/d4299593833/htdocs/pmma-helpdesk-app/resources/views/portal/partials/last-action.blade.php ENDPATH**/ ?>