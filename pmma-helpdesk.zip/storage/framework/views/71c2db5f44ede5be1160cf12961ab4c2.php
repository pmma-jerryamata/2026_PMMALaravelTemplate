<?php $__env->startSection('title', 'Services'); ?>
<?php $__env->startSection('content'); ?>
<?php echo $__env->make('portal.partials.heading', ['title' => 'Campus Services', 'subtitle' => 'Find the right support for your concern.'], array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?>
<section class="section"><div class="container"><form action="<?php echo e(route('services')); ?>" class="portal-search" role="search"><label for="service-search">Search the Service Directory</label><div class="search-input-wrapper"><input id="service-search" name="q" type="search" value="<?php echo e($query); ?>" placeholder="Search services, topics, or concerns" class="service-search-input" maxlength="150"><button class="search-submit-btn" aria-label="Search services"><i class="bi bi-search" aria-hidden="true"></i></button></div></form><p class="text-muted"><?php echo e($services->count()); ?> <?php echo e(Str::plural('service', $services->count())); ?><?php echo e($query !== '' ? ' found for “'.$query.'”' : ' available'); ?> <?php if($query !== ''): ?> · <a href="<?php echo e(route('services')); ?>">Clear Search</a><?php endif; ?></p><div class="home-services-grid"><?php echo $__env->make('portal.partials.cards', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?></div><?php if($services->isEmpty()): ?><div class="portal-empty"><i class="bi bi-search" aria-hidden="true"></i><h2>No Services Found</h2><p>Try another search term or submit a general inquiry.</p><a href="<?php echo e(route('tickets.create', ['category' => 'others'])); ?>" class="btn btn-primary ui-action" aria-label="Submit an Inquiry" title="Submit an Inquiry"><?php if (isset($component)) { $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-icon','data' => ['name' => 'send']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'send']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $attributes = $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $component = $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?><span>Submit an Inquiry</span></a></div><?php endif; ?></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.portal', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /homepages/40/d4299593833/htdocs/pmma-helpdesk-app/resources/views/portal/services.blade.php ENDPATH**/ ?>