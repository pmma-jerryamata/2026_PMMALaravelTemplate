<?php $__env->startSection('title', 'Staff Login'); ?>
<?php $__env->startSection('content'); ?>
<section class="section login-section"><div class="container"><div class="login-panel portal-panel"><img src="<?php echo e(asset('assets/images/pmma-seal.png')); ?>" alt="PMMA seal" width="72" height="72"><span class="portal-eyebrow"><?php echo e($systemSettings['app_name']); ?></span><h1>Welcome Back</h1><p>Sign In to manage support requests.</p><?php if($errors->any()): ?><div class="portal-alert error" role="alert"><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?><form action="<?php echo e(route('login.submit')); ?>" method="post" class="portal-form"><?php echo csrf_field(); ?><label for="email">Username or Email</label><input id="email" type="text" name="email" value="<?php echo e(old('email')); ?>" autocomplete="username" required maxlength="254"><label for="password">Password</label><div class="password-wrapper"><input id="password" type="password" name="password" autocomplete="current-password" required><button type="button" class="password-toggle" aria-label="Show Password" aria-controls="password" aria-pressed="false"><i class="bi bi-eye" aria-hidden="true"></i></button></div><button class="btn btn-primary ui-action" type="submit" aria-label="Sign In" title="Sign In"><?php if (isset($component)) { $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-icon','data' => ['name' => 'box-arrow-in-right']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'box-arrow-in-right']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $attributes = $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $component = $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?><span>Sign In</span></button></form><p class="text-muted login-help">Staff access only. Contact your helpdesk administrator for an account.</p><a href="<?php echo e(route('home')); ?>">← Back to Support Services</a></div></div></section>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.auth', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH /homepages/40/d4299593833/htdocs/pmma-helpdesk-app/resources/views/auth/login.blade.php ENDPATH**/ ?>