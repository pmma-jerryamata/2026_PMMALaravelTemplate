<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="theme-color" content="#10264b">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title><?php echo $__env->yieldContent('title', 'Dashboard'); ?> | <?php echo e($systemSettings['app_name']); ?></title>
    <link rel="icon" href="<?php echo e(asset('assets/images/pmma-seal.png')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/style.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/accessibility.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/icons/bootstrap-icons.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/vendor/datatables/dataTables.min.css')); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/pmma.css')); ?>?v=<?php echo e(filemtime(public_path('assets/css/pmma.css'))); ?>">
    <link rel="stylesheet" href="<?php echo e(asset('assets/css/dashboard-theme.css')); ?>?v=<?php echo e(filemtime(public_path('assets/css/dashboard-theme.css'))); ?>">
    <script src="<?php echo e(asset('assets/vendor/datatables/jquery.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/vendor/datatables/dataTables.min.js')); ?>" defer></script>
    <script src="<?php echo e(asset('assets/vendor/chartjs/chart.umd.min.js')); ?>" defer></script>
    <?php echo app('Illuminate\Foundation\Vite')(['resources/css/app.css', 'resources/js/app.js']); ?>
</head>
<body class="admin-workspace">
<div id="staff-app" data-dashboard-url="<?php echo e(route('dashboard')); ?>">
<a class="skip-link" href="#main-content">Skip to main content</a>
<aside id="staff-sidebar" class="admin-sidebar" aria-label="Staff sidebar">
    <a class="admin-brand" href="<?php echo e(route('dashboard')); ?>"><img src="<?php echo e(asset('assets/images/pmma-seal.png')); ?>" width="48" height="48" alt="PMMA seal"><span><strong><?php echo e($systemSettings['app_name']); ?></strong><small>STAFF WORKSPACE</small></span></a>
    <span class="admin-nav-label">WORKSPACE</span>
    <button type="button" class="admin-menu-close" aria-label="Close navigation"><i class="bi bi-x-lg" aria-hidden="true"></i></button>
    <nav id="staff-navigation" aria-label="Staff navigation">
        <a href="<?php echo e(route('dashboard')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['selected' => request()->routeIs('dashboard') && !request('status')]); ?>"><i class="bi bi-grid-1x2" aria-hidden="true"></i> Overview</a>
        <a href="<?php echo e(route('dashboard', ['status' => 'Open'])); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['selected' => request('status') === 'Open']); ?>"><i class="bi bi-inbox" aria-hidden="true"></i> Open Tickets</a>
        <a href="<?php echo e(route('dashboard', ['status' => 'In Progress'])); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['selected' => request('status') === 'In Progress']); ?>"><i class="bi bi-arrow-repeat" aria-hidden="true"></i> In Progress</a>
        <a href="<?php echo e(route('dashboard', ['status' => 'Resolved'])); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['selected' => request('status') === 'Resolved']); ?>"><i class="bi bi-check2-circle" aria-hidden="true"></i> Resolved Tickets</a>
        <a href="<?php echo e(route('dashboard', ['status' => 'Closed'])); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['selected' => request('status') === 'Closed']); ?>"><i class="bi bi-archive" aria-hidden="true"></i> Closed Tickets</a>
        <a href="<?php echo e(route('dashboard.queue')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['selected' => request()->routeIs('dashboard.queue*')]); ?>"><i class="bi bi-kanban" aria-hidden="true"></i> Ticket Queue</a>
        <a href="<?php echo e(route('dashboard.settings')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['selected' => request()->routeIs('dashboard.settings')]); ?>"><i class="bi bi-gear" aria-hidden="true"></i> System Settings</a>
        <?php if (app(\Illuminate\Contracts\Auth\Access\Gate::class)->check('view-activity-logs')): ?>
        <a href="<?php echo e(route('dashboard.activity-logs')); ?>" class="<?php echo \Illuminate\Support\Arr::toCssClasses(['selected' => request()->routeIs('dashboard.activity-logs*')]); ?>"><i class="bi bi-journal-text" aria-hidden="true"></i> Activity Logs</a>
        <?php endif; ?>
    </nav>
    <div class="admin-sidebar-bottom"><span>Information Technology Services Unit</span></div>
</aside>
<button type="button" class="admin-menu-backdrop" aria-label="Close navigation" tabindex="-1" hidden></button>
<div class="admin-shell">
    <header class="admin-topbar"><button type="button" class="admin-menu-toggle" aria-label="Open navigation" aria-controls="staff-sidebar" aria-expanded="false"><i class="bi bi-list" aria-hidden="true"></i></button><div><span class="admin-topbar-label">PMMA / Support Operations</span><strong><?php echo $__env->yieldContent('title', 'Dashboard'); ?></strong></div><div class="admin-account"><?php ($avatarProfile = auth()->user()->technician); ?> <?php if($avatarProfile?->photo_path && \Illuminate\Support\Facades\Storage::disk('local')->exists($avatarProfile->photo_path)): ?><img class="admin-avatar admin-avatar-photo" src="<?php echo e(route('dashboard.technicians.photo', $avatarProfile)); ?>?v=<?php echo e($avatarProfile->updated_at->timestamp); ?>" alt="<?php echo e(auth()->user()->name); ?> profile photo" width="36" height="36"><?php else: ?><span class="admin-avatar"><?php echo e(mb_substr(auth()->user()->name, 0, 1)); ?></span><?php endif; ?><span class="admin-account-name"><?php echo e(auth()->user()->name); ?><small>Helpdesk Staff</small></span><form method="post" action="<?php echo e(route('logout')); ?>"><?php echo csrf_field(); ?><button type="submit" class="staff-logout ui-action" aria-label="Logout" title="Logout"><i class="bi bi-box-arrow-right" aria-hidden="true"></i><span>Logout</span></button></form></div></header>
    <main id="main-content" class="admin-content">
        <p id="dashboard-notice" role="status" aria-live="polite"></p>
        <?php if($errors->any()): ?><div class="portal-alert error" role="alert"><ul><?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?><li><?php echo e($error); ?></li><?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?></ul></div><?php endif; ?>
        <?php echo $__env->yieldContent('content'); ?>
    </main>
</div>
<dialog id="editor-dialog" class="admin-dialog" aria-labelledby="editor-title"><div class="dialog-heading"><h2 id="editor-title">Edit Record</h2><button type="button" data-close-dialog aria-label="Close Dialog" title="Close Dialog"><?php if (isset($component)) { $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-icon','data' => ['name' => 'x-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x-lg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $attributes = $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $component = $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?></button></div><form id="editor-form" class="portal-form"><div id="editor-errors" role="alert"></div><div id="editor-fields" class="form-grid"></div><div class="dialog-actions"><button type="button" class="btn btn-secondary ui-action" data-close-dialog aria-label="Cancel" title="Cancel"><?php if (isset($component)) { $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-icon','data' => ['name' => 'x-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x-lg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $attributes = $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $component = $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?><span>Cancel</span></button><button type="submit" class="btn btn-primary ui-action" aria-label="Save Changes" title="Save Changes"><?php if (isset($component)) { $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-icon','data' => ['name' => 'floppy']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'floppy']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $attributes = $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $component = $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?><span>Save Changes</span></button></div></form></dialog>
<?php echo $__env->yieldPushContent('dashboard-data'); ?>
<dialog id="timeline-dialog" class="admin-dialog" aria-labelledby="timeline-title"><div class="dialog-heading"><h2 id="timeline-title">Ticket Timeline</h2><button type="button" data-close-timeline aria-label="Close Timeline" title="Close Timeline"><?php if (isset($component)) { $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729 = $component; } ?>
<?php if (isset($attributes)) { $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729 = $attributes; } ?>
<?php $component = Illuminate\View\AnonymousComponent::resolve(['view' => 'components.action-icon','data' => ['name' => 'x-lg']] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? $attributes->all() : [])); ?>
<?php $component->withName('action-icon'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag): ?>
<?php $attributes = $attributes->except(\Illuminate\View\AnonymousComponent::ignoredParameterNames()); ?>
<?php endif; ?>
<?php $component->withAttributes(['name' => 'x-lg']); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $attributes = $__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__attributesOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729)): ?>
<?php $component = $__componentOriginal2b612bcbad651c78da47ba0e8d4b3729; ?>
<?php unset($__componentOriginal2b612bcbad651c78da47ba0e8d4b3729); ?>
<?php endif; ?></button></div><div id="timeline-content" aria-live="polite"></div><div class="dialog-actions"><button type="button" class="btn btn-secondary ui-action" data-close-timeline>Close</button></div></dialog>
</div>
</body>
</html>
<?php /**PATH /homepages/40/d4299593833/htdocs/pmma-helpdesk-app/resources/views/layouts/dashboard.blade.php ENDPATH**/ ?>