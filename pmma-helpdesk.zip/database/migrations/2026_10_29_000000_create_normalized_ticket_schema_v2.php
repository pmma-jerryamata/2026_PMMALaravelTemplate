<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('ticket_statuses', function (Blueprint $table) {
            $table->id();
            $table->string('code', 40)->unique();
            $table->string('label', 80);
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->boolean('is_terminal')->default(false);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('ticket_priorities', function (Blueprint $table) {
            $table->id();
            $table->string('code', 40)->unique();
            $table->string('label', 80);
            $table->unsignedSmallInteger('sort_order')->default(0);
            $table->boolean('is_active')->default(true);
            $table->timestamps();
        });

        Schema::create('ticket_assignments', function (Blueprint $table) {
            $table->id();
            $table->foreignId('ticket_id')->constrained()->cascadeOnDelete();
            $table->foreignId('technician_id')->nullable()->constrained()->nullOnDelete();
            $table->foreignId('assigned_by')->nullable()->constrained('users')->nullOnDelete();
            $table->timestamp('assigned_at')->useCurrent();
            $table->timestamp('unassigned_at')->nullable();
            $table->index(['ticket_id', 'unassigned_at']);
            $table->index(['technician_id', 'unassigned_at']);
        });

        Schema::table('tickets', function (Blueprint $table) {
            $table->foreignId('status_id')->nullable()->after('status')->constrained('ticket_statuses')->nullOnDelete();
            $table->foreignId('priority_id')->nullable()->after('priority')->constrained('ticket_priorities')->nullOnDelete();
            $table->foreignId('service_category_id')->nullable()->after('category')->constrained('service_categories')->nullOnDelete();
            $table->index(['status_id', 'created_at'], 'tickets_status_v2_created');
            $table->index(['priority_id', 'created_at'], 'tickets_priority_v2_created');
        });

        $now = now();
        DB::table('ticket_statuses')->insert([
            ['code' => 'open', 'label' => 'Open', 'sort_order' => 10, 'is_terminal' => false, 'is_active' => true, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'in_progress', 'label' => 'In Progress', 'sort_order' => 20, 'is_terminal' => false, 'is_active' => true, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'resolved', 'label' => 'Resolved', 'sort_order' => 30, 'is_terminal' => true, 'is_active' => true, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'closed', 'label' => 'Closed', 'sort_order' => 40, 'is_terminal' => true, 'is_active' => true, 'created_at' => $now, 'updated_at' => $now],
        ]);
        DB::table('ticket_priorities')->insert([
            ['code' => 'normal', 'label' => 'Normal', 'sort_order' => 10, 'is_active' => true, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'high', 'label' => 'High', 'sort_order' => 20, 'is_active' => true, 'created_at' => $now, 'updated_at' => $now],
            ['code' => 'urgent', 'label' => 'Urgent', 'sort_order' => 30, 'is_active' => true, 'created_at' => $now, 'updated_at' => $now],
        ]);

        foreach (DB::table('tickets')->select(['id', 'status', 'priority', 'category', 'technician_id', 'created_at'])->cursor() as $ticket) {
            $statusId = DB::table('ticket_statuses')->whereRaw('LOWER(label) = ?', [strtolower((string) $ticket->status)])->value('id');
            $priorityId = DB::table('ticket_priorities')->where('code', strtolower((string) $ticket->priority))->value('id');
            $categoryId = DB::table('service_categories')->where('slug', $ticket->category)->value('id');
            DB::table('tickets')->where('id', $ticket->id)->update(['status_id' => $statusId, 'priority_id' => $priorityId, 'service_category_id' => $categoryId]);
            if ($ticket->technician_id) {
                DB::table('ticket_assignments')->insert(['ticket_id' => $ticket->id, 'technician_id' => $ticket->technician_id, 'assigned_at' => $ticket->created_at ?? $now]);
            }
        }

        DB::table('system_settings')->insertOrIgnore([
            ['key' => 'app_name', 'value' => 'PMMA Helpdesk'],
            ['key' => 'portal_subtitle', 'value' => 'Ticket Support Portal'],
            ['key' => 'support_tagline', 'value' => 'Your campus support, in one place'],
            ['key' => 'footer_credit', 'value' => 'Developed and Maintained by PMMA Information Technology Services Unit'],
        ]);
    }

    public function down(): void
    {
        Schema::table('tickets', function (Blueprint $table) {
            $table->dropForeign(['service_category_id']);
            $table->dropForeign(['priority_id']);
            $table->dropForeign(['status_id']);
            $table->dropIndex('tickets_status_v2_created');
            $table->dropIndex('tickets_priority_v2_created');
            $table->dropColumn(['service_category_id', 'priority_id', 'status_id']);
        });
        Schema::dropIfExists('ticket_assignments');
        Schema::dropIfExists('ticket_priorities');
        Schema::dropIfExists('ticket_statuses');
    }
};
