<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('deployment_histories', function (Blueprint $table) {
            $table->id();
            $table->string('release', 120);
            $table->string('summary', 255);
            $table->string('environment', 30)->default('production');
            $table->foreignId('deployed_by')->nullable()->constrained('users')->nullOnDelete();
            $table->string('deployed_by_name', 120)->nullable();
            $table->json('changed_files')->nullable();
            $table->timestamp('deployed_at')->useCurrent();
            $table->timestamps();
            $table->index(['environment', 'deployed_at']);
        });
    }

    public function down(): void { Schema::dropIfExists('deployment_histories'); }
};
