# PMMA Ticket System

Laravel 12 campus support portal, with the page layout and styles adapted from the BetterCalauan react-typescript branch. See [design attribution](THIRD_PARTY_NOTICES.md).

## Run locally

Requirements: PHP 8.2+, Composer, PDO MySQL, and the XAMPP MySQL/MariaDB service. Enable the PHP ZIP extension when installing Composer dependencies.

```sh
composer install
```

Start MySQL in XAMPP. Create the `pmma_helpdesk` database with utf8mb4_unicode_ci collation. On a fresh checkout, copy `.env.example` to `.env`, adjust the local database credentials if needed, then run:

```sh
php artisan key:generate
php artisan migrate
php artisan serve
```

Open http://127.0.0.1:8000. The supplied VS Code task **Serve Laravel** also starts the application. On XAMPP, point the virtual host document root at this project's `public` directory.

## Implemented

- Shared responsive header, mobile navigation, Philippine time bar, hero, service cards, and footer.
- Searchable campus service directory and service detail pages.
- Ticket submission with server validation, CSRF protection, rate limiting, and MySQL/MariaDB persistence.
- Confirmation with a unique reference number and copy action.
- Tracking by reference number, including the complete recorded progress timeline.
- FAQs, contact, and privacy pages.

Portal assets, including Bootstrap Icons, are served locally. These Blade pages do not require an npm build. The Laravel default Vite tooling remains available for future frontend work.

## Current scope

The app includes the public request portal and protected staff workspace. Ticket attachments and automatic email notifications are not included. Newly submitted tickets start as Open. Service categories are stored in the database and managed from System Settings; the configuration file provides initial migration defaults.

## Verify

```sh
php artisan test
```

Tests cover public pages, service search, invalid requests, ticket persistence, and reference-only tracking and timeline checks. Tests use an isolated in-memory database.

## Staff dashboard

Visit `/login` to access the staff dashboard. Create an authorized account from the project terminal:

```sh
php artisan helpdesk:create-staff
```

Enter the staff name, email, and a password of at least 12 characters. Password input is hidden. Public registration is disabled. The dashboard supports ticket counts, searching, status filters, ticket details, assignment to active technician profiles, and status updates. In Progress requires a technician assignment. System Settings provides department, technician profile/photo, service category, branding, and personal staff account editors. Add/edit and ticket management controls use dashboard modals. Ticket and settings tables use locally hosted DataTables with search, sorting, page-size controls, and pagination. Inactive records are retained for ticket history.

## Overview analytics

The overview contains concern-category trends, department counts, and total ticket volume charts. Period controls switch all three charts between the last 14 daily buckets, 12 Monday-based weekly buckets, and 12 monthly buckets, including the current partial period. Dates are grouped in Asia/Manila. Graphs follow status, department, category, and search filters; summary cards retain all-time totals. View Chart Data provides exact values. Charts use locally hosted Chart.js.

## Activity logs

Application page requests, public ticket submissions/tracking, login/logout (including failures), and staff dashboard/settings operations are recorded in the activity_logs table. The existing local Development Admin account has an explicit is_dev_admin flag. Only authenticated staff with this flag can access the read-only Activity Logs page and its data endpoint; regular staff and requestees cannot access it. Logs support IP/user search, operation/result filters, Philippine-time date ranges, sorting, and server-side DataTables pagination. No raw request bodies, passwords, session tokens, or uploaded contents are recorded. Clock polling and static assets are excluded. Collection begins when this feature is installed.

## Ticket timeline and staff controls

Ticket details editing and status/technician/action updates use separate modals and endpoints. Every submission and tracked field change creates a chronological ticket update; staff action notes appear in both the staff timeline viewer and public tracking. New action notes are required for technician updates. Existing tickets have an initial submission entry and, when applicable, an explicitly marked imported state; earlier actions that were not recorded are not invented.

Public tracking now requires the ticket reference only. The landing page includes a read-only DataTable of requests created within the rolling past 24 hours, with ticket number, issue, department, and View Timeline only. Requester names and emails are excluded from this list. The recent table is not displayed on the staff dashboard.

## Capacity and database protection

For the single XAMPP host, sessions and cache now use files instead of SQL. Switching session stores requires signing in again. Branding and service catalog reads are cached for 60 seconds, with invalidation on application model updates. Ticket lists use server-side DataTables with 10 initial rows and a maximum page size of 100. Ticket query indexes cover dates, status, department and category. Analytics runs only on Overview, and scans records in batches of 500.

HELPDESK_MAX_CONCURRENT_REQUESTS=20 limits admitted application requests before sessions/authentication open database connections. Local OS file locks are held through response termination and audit logging, and automatically released if a worker exits. Excess requests receive HTTP 503 with Retry-After: 5. This rejects excess work; it is not a durable submission queue and never confirms an unsaved ticket. Connection exhaustion, database unavailability and lock timeouts get a standalone busy response without querying page branding. Ticket creation and its timeline entry commit together in a transaction.

The current MariaDB max_connections was 151 (observed peak 4); its Windows thread pool was already enabled. No global database limit was raised. Keep the application cap below the database limit, reserving capacity for administration, other applications and background workers. File admission limits are per host and protect HTTP traffic only: multiple hosts need a shared limiter or proxy, shared sessions/cache (e.g. Redis), and a total worker connection budget. The PHP development server is not a production concurrency benchmark; production capacity still needs testing on Apache/PHP with representative traffic.
