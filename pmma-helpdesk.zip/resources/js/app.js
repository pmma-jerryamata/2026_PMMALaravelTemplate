import './bootstrap';
import { createApp } from 'vue';
import StaffWorkspace from './components/StaffWorkspace.vue';

const dashboard = document.querySelector('#staff-app');
if (dashboard) {
    createApp(StaffWorkspace, {
        initialHtml: dashboard.innerHTML,
        dashboardUrl: dashboard.dataset.dashboardUrl,
    }).mount(dashboard);
}
