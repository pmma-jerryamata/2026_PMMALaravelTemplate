<script setup>
import { createApp, nextTick, onMounted, onBeforeUnmount, ref } from 'vue';
import { createPinia } from 'pinia';
import TicketDashboard from './TicketDashboard.vue';
import { initDashboard } from '../../../public/assets/js/dashboard.js';
import { initAnalytics } from '../../../public/assets/js/analytics.js';

const props = defineProps({ initialHtml: String, dashboardUrl: String });
const html = ref(props.initialHtml);
const loading = ref(false);
const error = ref('');
const content = ref(null);
const base = new URL(props.dashboardUrl).pathname.replace(/\/$/, '');
let request, ticketApp, stopDashboard, stopAnalytics;
let currentUrl = location.href;

function isStaffPage(url) {
    if (url.origin !== location.origin) return false;
    const path = url.pathname;
    return path === base || path === `${base}/settings` || path === `${base}/activity-logs`
        || (path.startsWith(`${base}/tickets/`) && /^\d+$/.test(path.slice(`${base}/tickets/`.length)));
}

function cleanup() {
    ticketApp?.unmount(); ticketApp = null;
    stopDashboard?.(); stopDashboard = null;
    stopAnalytics?.(); stopAnalytics = null;
}

function initialize() {
    stopDashboard = initDashboard();
    stopAnalytics = initAnalytics();
    const table = content.value.querySelector('#vue-ticket-dashboard');
    if (table) {
        ticketApp = createApp(TicketDashboard, {
            source: table.dataset.source,
            options: JSON.parse(table.dataset.options || '{}'),
        }).use(createPinia());
        ticketApp.mount(table);
    }
}

async function navigate(target, { historyMode = 'push', preserveScroll = false } = {}) {
    request?.abort();
    const active = request = new AbortController();
    loading.value = true; error.value = '';
    try {
        const response = await fetch(target, {
            signal: active.signal, credentials: 'same-origin', cache: 'no-store',
            headers: { Accept: 'text/html' },
        });
        if (!response.ok) throw new Error(`Unable to load page (${response.status}). Please try again.`);
        const page = new DOMParser().parseFromString(await response.text(), 'text/html');
        if (active !== request) return;
        const next = page.getElementById('staff-app');
        if (!next || !isStaffPage(new URL(response.url))) {
            if (response.redirected) { location.assign(response.url); return; }
            throw new Error('Unable to load this workspace page. Please try again.');
        }
        cleanup();
        const url = new URL(response.url);
        url.hash = new URL(target, location.href).hash;
        if (historyMode === 'push') history.pushState({}, '', url);
        else if (historyMode === 'replace') history.replaceState({}, '', url);
        document.title = page.title;
        const csrf = page.querySelector('meta[name="csrf-token"]')?.content;
        if (csrf) document.querySelector('meta[name="csrf-token"]').content = csrf;
        html.value = next.innerHTML;
        await nextTick();
        initialize();
        currentUrl = location.href;
        if (!preserveScroll) {
            window.scrollTo(0, 0);
            const main = content.value.querySelector('main');
            main?.setAttribute('tabindex', '-1'); main?.focus({ preventScroll: true });
        }
    } catch (failure) {
        if (failure.name !== 'AbortError') {
            error.value = failure.message;
            if (historyMode === 'pop') history.replaceState({}, '', currentUrl);
        }
    } finally {
        if (active === request) loading.value = false;
    }
}

function click(event) {
    if (event.defaultPrevented || event.button !== 0 || event.ctrlKey || event.metaKey || event.shiftKey || event.altKey) return;
    const link = event.target.closest('a[href]');
    if (!link || link.hasAttribute('download') || (link.target && link.target !== '_self')) return;
    const url = new URL(link.href);
    if (!isStaffPage(url) || (url.hash && url.pathname === location.pathname && url.search === location.search)) return;
    event.preventDefault(); navigate(url.href);
}

async function submit(event) {
    const form = event.target;
    if (event.defaultPrevented || form.id === 'editor-form') return;
    const url = new URL(form.action);
    if (form.method.toLowerCase() === 'get' && isStaffPage(url)) {
        event.preventDefault();
        url.search = new URLSearchParams(new FormData(form)).toString();
        navigate(url.href);
    } else if (url.origin === location.origin && url.pathname.startsWith(`${base}/tickets/`) && url.pathname.endsWith('/action')) {
        event.preventDefault();
        const button = event.submitter; if (button) button.disabled = true;
        try {
            const response = await fetch(url, { method: 'POST', body: new FormData(form), headers: { Accept: 'application/json' } });
            const data = await response.json();
            if (!response.ok) throw new Error(data.errors ? Object.values(data.errors).flat().join(' ') : data.message);
            sessionStorage.setItem('dashboard-success', data.message);
            await refresh();
        } catch (failure) { error.value = failure.message || 'Unable to save changes.'; }
        finally { if (button) button.disabled = false; }
    }
}

const refresh = () => navigate(location.href, { historyMode: 'replace', preserveScroll: true });
const pop = () => navigate(location.href, { historyMode: 'pop' });
onMounted(() => {
    initialize();
    window.addEventListener('popstate', pop);
    document.addEventListener('staff:refresh', refresh);
});
onBeforeUnmount(() => {
    request?.abort(); cleanup();
    window.removeEventListener('popstate', pop);
    document.removeEventListener('staff:refresh', refresh);
});
</script>

<template>
    <p v-if="loading" class="workspace-progress" role="status">Loading page…</p>
    <div v-if="error" class="workspace-error portal-alert error" role="alert">
        {{ error }} <button type="button" @click="refresh">Try again</button>
    </div>
    <div ref="content" :aria-busy="loading" @click="click" @submit="submit" v-html="html"></div>
</template>

<style>
.workspace-progress, .workspace-error { position: fixed; top: 0; left: 50%; transform: translateX(-50%); z-index: 10000; margin: 0; padding: .65rem 1rem; background: #fff; box-shadow: 0 2px 12px #10264b25; }
.workspace-progress { border-bottom: 3px solid #0032a0; }
</style>
