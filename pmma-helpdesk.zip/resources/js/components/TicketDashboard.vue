<script setup>
import { computed, reactive, watch, onBeforeUnmount } from 'vue';
import axios from 'axios';
import { useTicketStore } from '../stores/ticketStore';

const props = defineProps({ source: String, csrf: String, options: Object });
const store = useTicketStore();
const query = new URLSearchParams(location.search);
const filters = reactive({ q: query.get('q') || '', status: query.get('status') || '', department_id: query.get('department_id') || '', category: query.get('category') || '' });
const pages = computed(() => Math.max(1, Math.ceil(store.filtered / store.perPage)));

function load() { store.fetch(props.source, filters); }
function filter() { store.page = 1; load(); }
function page(value) { store.page = Math.min(Math.max(1, value), pages.value); load(); }
async function remove(ticket) {
    if (!window.confirm(`Delete ticket ${ticket.reference}?`)) return;
    try {
        await store.remove(ticket.url);
        document.dispatchEvent(new CustomEvent('staff:refresh'));
    } catch (error) { store.error = error.response?.data?.message || 'Unable to delete this ticket.'; }
}
watch(() => store.perPage, load);
load();
onBeforeUnmount(() => store.cancel());
</script>

<template>
    <div class="vue-ticket-dashboard">
        <form class="dashboard-filters" @submit.prevent="filter">
            <input v-model="filters.q" placeholder="Search reference, subject, or requester" maxlength="200">
            <select v-model="filters.status"><option value="">All Statuses</option><option v-for="status in options.statuses" :key="status">{{ status }}</option></select>
            <select v-model="filters.department_id"><option value="">All Departments</option><option v-for="department in options.departments" :value="department.id" :key="department.id">{{ department.name }}</option></select>
            <select v-model="filters.category"><option value="">All Concern Categories</option><option v-for="(service, slug) in options.services" :value="slug" :key="slug">{{ service.title }}</option></select>
            <button class="btn btn-primary ui-action" type="submit">Filter</button>
        </form>
        <p v-if="store.error" class="portal-alert error" role="alert">{{ store.error }}</p>
        <div class="dashboard-table-wrap">
            <table class="dashboard-table">
                <thead><tr><th>Ticket / Concern</th><th>Requester</th><th>Priority</th><th>Status</th><th>Technician</th><th>Submitted</th><th>Actions</th></tr></thead>
                <tbody>
                    <tr v-if="store.loading"><td colspan="7">Loading tickets…</td></tr>
                    <tr v-else-if="!store.rows.length"><td colspan="7">No tickets found.</td></tr>
                    <tr v-for="ticket in store.rows" :key="ticket.id">
                        <td><strong>{{ ticket.reference }}</strong><br><span>{{ ticket.subject }}</span></td>
                        <td>{{ ticket.name }}<small>{{ ticket.department?.name || 'Not Specified' }}</small></td>
                        <td><span :class="`priority-tag priority-${ticket.priority.toLowerCase()}`">{{ ticket.priority }}</span></td>
                        <td><span class="dashboard-status">{{ ticket.status }}</span></td>
                        <td>{{ ticket.technician?.name || 'Unassigned' }}</td>
                        <td>{{ ticket.created_at }}</td>
                        <td>
                            <a class="btn btn-secondary icon-action" :href="ticket.url" :aria-label="`Open Ticket ${ticket.reference}`" title="Open Ticket"><i class="bi bi-eye" aria-hidden="true"></i></a>
                            <button type="button" class="btn btn-secondary icon-action ticket-delete" :aria-label="`Delete Ticket ${ticket.reference}`" title="Delete Ticket" @click="remove(ticket)"><i class="bi bi-trash" aria-hidden="true"></i></button>
                        </td>
                    </tr>
                </tbody>
            </table>
        </div>
        <div class="dashboard-pagination"><button class="btn btn-secondary" :disabled="store.page <= 1" @click="page(store.page - 1)">Previous</button><span>Page {{ store.page }} of {{ pages }}</span><button class="btn btn-secondary" :disabled="store.page >= pages" @click="page(store.page + 1)">Next</button></div>
    </div>
</template>
