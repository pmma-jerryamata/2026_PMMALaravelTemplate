import { defineStore } from 'pinia';
import axios from 'axios';

export const useTicketStore = defineStore('tickets', {
    state: () => ({ rows: [], total: 0, filtered: 0, loading: false, error: null, page: 1, perPage: 10 }),
    actions: {
        cancel() { this._request?.abort(); },
        async fetch(source, filters = {}) {
            this.cancel();
            const request = this._request = new AbortController();
            this.loading = true;
            this.error = null;
            try {
                const { data } = await axios.get(source, { signal: request.signal, params: { ...filters, page: this.page, per_page: this.perPage } });
                if (request !== this._request) return;
                this.rows = data.data;
                this.total = data.meta.total;
                this.filtered = data.meta.filtered;
            } catch (error) {
                if (!axios.isCancel(error)) this.error = error.response?.data?.message || 'Unable to load tickets.';
            } finally { if (request === this._request) this.loading = false; }
        },
        async remove(url) { await axios.delete(url); const id = Number(url.split('/').pop()); this.rows = this.rows.filter(row => row.id !== id); },
    },
});
