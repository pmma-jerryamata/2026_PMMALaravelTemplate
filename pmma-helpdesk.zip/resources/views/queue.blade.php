<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8"><meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="robots" content="noindex,nofollow">
    <title>Live Ticket Queue | {{ $systemSettings['app_name'] }}</title>
    <link rel="icon" href="{{ asset('assets/images/pmma-seal.png') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/style.css') }}">
    <link rel="stylesheet" href="{{ asset('assets/css/pmma.css') }}?v=queue-13">
    <link rel="stylesheet" href="{{ asset('assets/icons/bootstrap-icons.css') }}">
</head>
<body class="queue-page">
<header class="queue-topbar"><div class="queue-header-row"><div class="queue-brand"><img src="{{ asset('assets/images/pmma-seal.png') }}" alt="PMMA seal"><span><strong>{{ $systemSettings['app_name'] }}</strong><small>PMMA SUPPORT OPERATIONS</small></span></div><div class="queue-clock"><strong id="queue-time">--</strong><small id="queue-date">PST</small></div></div></header>
<main id="queue-app" data-url="{{ $dataUrl }}" data-private="{{ $private ? '1' : '0' }}">
    <section class="queue-featured"><div class="now-serving"><div class="now-serving-label">NOW SERVING</div><div id="now-serving-ticket"><strong>Waiting for live queue...</strong></div></div><div class="next-in-line"><div class="next-label">NEXT IN LINE</div><div id="next-ticket"><strong>Waiting for tickets...</strong></div></div></section>
    <div class="queue-layout"><section class="queue-board" aria-live="polite"><div class="queue-columns">
        @foreach(['Open' => 'Open', 'In Progress' => 'In Progress', 'Resolved' => 'Resolved'] as $status => $label)
        <article class="queue-column" data-column="{{ $status }}"><header><h2>{{ $label }}</h2><strong data-column-count="{{ $status }}">0</strong></header><div class="queue-category-rows" data-status="{{ $status }}"></div></article>
        @endforeach
    </div></section><aside class="queue-sidebar"><div class="queue-side-heading"><h2>Recent Updates</h2><span>Live</span></div><div id="queue-updates"></div></aside></div>
</main>
<script>window.queueConfig={url:@json($dataUrl),private:@json($private)};</script><script src="{{ asset('assets/js/queue.js') }}?v=queue-10"></script>
</body></html>
