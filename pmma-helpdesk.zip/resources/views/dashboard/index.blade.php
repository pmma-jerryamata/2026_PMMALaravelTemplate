@extends('layouts.dashboard')
@section('title', 'Dashboard')
@section('content')
@php($ticketOptions = ['storeUrl' => route('dashboard.tickets.store'), 'departments' => $departments, 'technicians' => $technicians, 'services' => $services, 'statuses' => $statuses])
<h1 class="sr-only">Dashboard</h1>
<section class="section bg-alt"><div class="container">
    <div class="dashboard-metrics">@foreach(['Total Tickets' => $counts->sum(), 'Open' => $counts->get('Open', 0), 'In Progress' => $counts->get('In Progress', 0), 'Resolved' => $counts->get('Resolved', 0), 'Active Technicians' => $technicianCount] as $label => $count)<article class="metric-card"><span>{{ $label }}</span><strong>{{ $count }}</strong><small>{{ $label === 'Active Technicians' ? 'Available staff profiles' : 'All support requests' }}</small></article>@endforeach</div>
    @if(!request('status'))@include('dashboard.analytics')@endif
    <div class="portal-panel dashboard-tickets"><div class="section-heading-row"><div><h2>Support Tickets</h2><p>Review requests, assign technicians, and keep statuses up to date.</p></div><button type="button" class="btn btn-primary ui-action" data-new-ticket>＋ <span>New Ticket</span></button></div>
        <div id="vue-ticket-dashboard" data-source="{{ route('dashboard.tickets.data') }}" data-options="{{ json_encode($ticketOptions) }}"></div>
    </div>
</div></section>
@endsection
@push('dashboard-data')
<script type="application/json" id="ticket-options">@json($ticketOptions)</script>
@endpush
